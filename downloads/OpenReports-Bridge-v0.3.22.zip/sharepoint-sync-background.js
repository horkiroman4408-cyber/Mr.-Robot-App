/* SharePoint Bridge 0.3.22: saved source management; no SharePoint writes. */
'use strict';
(()=>{
 const TENANT='lppsa-my.sharepoint.com';
 const validUrl=value=>{try{const u=new URL(value);return u.protocol==='https:'&&u.hostname===TENANT&&!u.username&&!u.password;}catch{return false;}};
 const errorCode=e=>String(e?.message||e).slice(0,100);
 chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if(!['SP_SYNC_SET_SOURCE','SP_SYNC_CLEAR_SOURCE','SP_SYNC_GET_SOURCE'].includes(msg?.type))return false;
  const fromExtension=sender.id===chrome.runtime.id&&!sender.tab;
  const fromApp=sender.id===chrome.runtime.id&&sender.tab?.url?.startsWith('https://horkiroman4408-cyber.github.io/Mr.-Robot-App/');
  if(msg.type==='SP_SYNC_GET_SOURCE'){
   if(!fromExtension&&!fromApp)return false;
   chrome.storage.local.get('mr_sp_source').then(v=>respond({ok:true,configured:!!v.mr_sp_source})).catch(e=>respond({ok:false,error:errorCode(e)}));return true;
  }
  if(!fromExtension)return false;
  if(msg.type==='SP_SYNC_SET_SOURCE'){
   if(!validUrl(msg.url)){respond({ok:false,error:'INVALID_SHAREPOINT_LINK'});return false;}
   chrome.storage.local.set({mr_sp_source:msg.url}).then(()=>respond({ok:true})).catch(e=>respond({ok:false,error:errorCode(e)}));return true;
  }
  chrome.storage.local.remove(['mr_sp_source','mr_sp_manual_job']).then(()=>respond({ok:true})).catch(e=>respond({ok:false,error:errorCode(e)}));return true;
 });
})();
