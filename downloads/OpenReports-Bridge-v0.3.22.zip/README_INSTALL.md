Mr. Robot Bridge 0.3.22 - OpenReports + SharePoint

1. Replace the files in your existing unpacked extension folder, then click Reload in edge://extensions (or chrome://extensions). Do not install two Bridge copies.
2. In the Bridge popup, paste the shared SharePoint Excel link and press Zapisz / zamień link. The link is stored only in the browser extension.
3. In Obsada, press Odśwież dane. The first time, choose the folder Downloads/MrRobot/SharePoint when Edge asks for folder read permission. If this folder does not exist yet, download once from the Bridge popup first.
4. Click Odśwież dane on future uses. On a new browser session Edge may ask to authorize reading the folder again.
5. Change the source with a new link and Zapisz / zamień link; remove it with Usuń zapisany link. Previously saved Obsada data remains intact.
6. This is manual only. No timers, polling schedules or background file refresh. Excel source is never modified.

Limitations: The selected workbook is expected to download as Grafik procesowy (godziny).xlsx, in Downloads/MrRobot/SharePoint. The browser File System Access permission is required to read the downloaded copy. This integration is designed for Edge/Chrome desktop.
